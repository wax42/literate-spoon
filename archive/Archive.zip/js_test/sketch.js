

function setup() {

}

function draw() {
  ellipse(50, 50, 80, 80);
  text('a', 40, 40);
}